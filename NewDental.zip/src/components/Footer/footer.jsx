

import "./footer.css";
import footerData from "../../json/component.json"; // Ensure the correct path

function Footer() {
  if (!footerData || !footerData.footer) {
    console.error("Footer data is missing or not loaded correctly:", footerData);
    return null; // Prevents rendering if data is undefined
  }

  const { logo, sections } = footerData.footer;

  return (
    <div className="footer">
      {/* Footer Logo Section */}
    
     <div className="footer-logo">
        <div><span>.\</span></div>
        <div>{logo.text}</div>
        <p>{logo.tagline}</p>
        <button>
          {logo.socialIcons.map((icon, index) => (
            <span key={index} className={`bi bi-${icon} m-2`}></span>
          ))}
        </button>
      </div>

      {/* Footer Sections */}
      <div className="footer-sub">
        {sections.map((section, index) => (
          <div key={index}>
            <ol>
              <h3>{section.title}</h3>
              {section.items.map((item, idx) =>
                typeof item === "string" ? (
                  <li key={idx}>{item}</li>
                ) : (
                  <li key={idx} className={`bi ${item.icon}`}>{item.text}</li>
                )
              )}
            </ol>
          </div>
        ))}
      </div>
     </div>
 
  );
}

export default Footer;




