


import { motion } from "framer-motion";
import React from "react";
import "./HeroSection.css";
import heroDataJson from "../../json/component.json"; // Import JSON data

const HeroSection = () => {
  // Extract HeroSection data correctly
  const heroData = heroDataJson.components
    .flatMap(component => component.components || component) // Flatten nested components
    .find(component => component.name === "HeroSection");

  // Handle case when data is not found
  if (!heroData) {
    return <div>Error: HeroSection data not found in JSON</div>;
  }

  return (
    <div className="hero-container">
      {/* Navigation Section */}
      <div className="hero-sectionnav">
        {/* <div>
          <img src={heroData.logo} alt="logo" />
        </div> */}
        <div style={{margin:'7px'}}>
          {heroData.contact.phone}
         
        </div>
        <div> <button >{heroData.contact.buttonText}</button></div>
      </div>

      {/* Hero Text */}
      < motion.div 
        initial={{ opacity: 0, x: 200 }}  // Start hidden & off-screen
        whileInView={{ opacity: 1, x: 0 }}  // Trigger when in view
        transition={{ duration: 1 }}
        viewport={{ once: false, amount: 0.2 }} 
       
       className="hero-text">
        <h1>{heroData.heading}</h1>
        <p>{heroData.subheading}</p>
      </motion.div>

      {/* Scrolling Images */}
      <div className="image-slider">
        <div className="slider-track">
          {/* Primary Images */}
          {heroData.images.map((image, index) => (
            <img key={index} src={image} alt={`Slide ${index + 1}`} />
          ))}

          {/* Duplicate Images for Smooth Infinite Scrolling */}
          {heroData.images.map((image, index) => (
            <img key={`dup-${index}`} src={image} alt={`Slide ${index + 1}`} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
