
import React, { useEffect, useState } from "react";
import { Carousel } from "../../components/Carousel/carousel";

import HeroSection from "../../components/Herosection/herosection";
import { FinalSlider } from "../../components/Slider/slider";
import { SliderVideo } from "../../components/SliderVideo/slidervideo";

import MovingText from "../../components/BelowHeroSection/belowhero";

import Doctor from "../../components/DOCTOR/doctor";
import Footer from "../../components/Footer/footer";
import FooterImage from "../../components/AboveFooterSlider/fooimage";
// import MovingSlider from "../../components/MovingSlide/";
// import Bar from "../../BAR/Bar";
import Bar from"../../components/NAV-BAR/Bar";
import { Flogo } from "../../components/Whatsap-phone Icon/footerlogo";
import MovingSlider from "../../components/MovingSlider/movingSlider";

 
 export function Home() {
  // const [isSticky, setSticky] = useState(false);

  // useEffect(() => {
  //   const handleScroll = () => {
  //     if (window.scrollY > document.querySelector(".hero-container").offsetHeight) {
  //       setSticky(true);
  //     } else {
  //       setSticky(false);
  //     }
  //   };

  //   window.addEventListener("scroll", handleScroll);

  //   return () => {
  //     window.removeEventListener("scroll", handleScroll);
  //   };
  // }, []);

  return (
    <div>
      {/* Conditionally render Navbar based on isSticky */}
      {/* {isSticky && <Navbar isSticky={isSticky} />} */}
   <Bar/>
   <HeroSection />
   <MovingText/>
   <FinalSlider />
    
      {/* <AutoScrollCarousel/> */}
   <Doctor/>
     <MovingSlider/>
      <Carousel />
      <SliderVideo />
      <FooterImage/>
      <Footer/>
      <Flogo/>    
    </div>
  );
}




