import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import { Home } from './Pages/Home/Home';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(    
  <React.StrictMode>
    <Home/>
   

  </React.StrictMode>
);

reportWebVitals();
